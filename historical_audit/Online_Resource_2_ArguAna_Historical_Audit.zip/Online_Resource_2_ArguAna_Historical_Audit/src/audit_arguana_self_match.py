from pathlib import Path
import json
import numpy as np
import pandas as pd
from beir.datasets.data_loader import GenericDataLoader
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer
from sklearn.model_selection import StratifiedKFold
import run_confirmatory_beir as ref

root = Path(__file__).resolve().parents[1]
out = root / 'outputs' / 'router' / 'arguana_selfmatch_audit'
data = root / 'datasets' / 'arguana'
if not (data / 'corpus.jsonl').exists():
    raise SystemExit('Missing datasets/arguana/corpus.jsonl')
old = pd.read_csv(root / 'outputs/router/arguana_confirmatory_queries.csv', dtype={'query_id': str})
old = old.set_index('query_id')
train = pd.read_csv(root / 'outputs/router/router_train_enriched.csv')
train = train.loc[train['split'].eq('train')].reset_index(drop=True)
X = train[ref.FEATURES].to_numpy(dtype=float)
y = train['hybrid_helpful'].to_numpy(dtype=int)
assert len(train) == 647 and len(old) == 1406
OOF = np.empty(len(y))
for a, b in StratifiedKFold(5, shuffle=True, random_state=42).split(X, y):
    m = ref.model_factory()
    m.fit(X[a], y[a])
    OOF[b] = m.predict_proba(X[b])[:, 1]
threshold = float(np.median(OOF))
assert abs(threshold - 0.4994615425106149) < 1e-8
model = ref.model_factory()
model.fit(X, y)
docs, queries, qrels = GenericDataLoader(data_folder=str(data)).load(split='test')
assert len(qrels) == 1406 and set(qrels) == set(old.index)
ids = list(docs)
index = {doc_id: i for i, doc_id in enumerate(ids)}
texts = [(docs[d].get('title', '') + ' ' + docs[d].get('text', '')).strip() for d in ids]
tokens = [ref.tok(t) for t in texts]
token_sets = [set(t) for t in tokens]
title_sets = [set(ref.tok(docs[d].get('title', ''))) for d in ids]
bm25 = BM25Okapi(tokens)
enc = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2', device='cpu')
assert enc.max_seq_length == 256
emb = enc.encode(texts, batch_size=32, normalize_embeddings=True,
                 convert_to_numpy=True, show_progress_bar=True)

def top(scores, excluded=None):
    if excluded is None:
        return np.argsort(-scores)[:5]
    s = scores.copy()
    s[excluded] = -np.inf
    return np.argsort(-s)[:5]

def prediction(qtokens, scores, btop):
    values = [len(qtokens), len(set(qtokens)), float(scores[btop[0]]),
              float(scores[btop[1]]), float(scores[btop[0]] - scores[btop[1]]),
              float(np.mean(scores[btop]))]
    values += ref.extra_features(set(qtokens), btop, scores, token_sets, title_sets)
    p = float(model.predict_proba(np.array(values).reshape(1, -1))[0, 1])
    return p, int(p >= threshold), values[4]

rows = []
for n, qid in enumerate(sorted(qrels), 1):
    qt = ref.tok(queries[qid])
    scores = bm25.get_scores(qt)
    qe = enc.encode([queries[qid]], normalize_embeddings=True,
                    convert_to_numpy=True)[0]
    dense = emb @ qe
    bt = top(scores)
    dt = top(dense)
    br = [ids[i] for i in bt]
    dr = [ids[i] for i in dt]
    prob, route, margin = prediction(qt, scores, bt)
    b = ref.ndcg(br, qrels[qid])
    h = ref.ndcg(ref.rrf(br, dr, k=10), qrels[qid])
    r = h if route else b
    hist = old.loc[qid]
    for key, value in [('bm25_ndcg', b), ('hybrid_ndcg', h),
                       ('router_ndcg', r), ('probability', prob),
                       ('run_dense', route), ('bm25_margin', margin)]:
        tol = 1e-7 if key == 'bm25_margin' else 1e-8
        if abs(float(hist[key]) - value) > tol:
            raise RuntimeError(f'Historical replication failed: query={qid}, {key}: '
                               f'original={hist[key]}, reproduced={value}')
    ix = index.get(qid)
    bt2 = top(scores, ix)
    dt2 = top(dense, ix)
    br2 = [ids[i] for i in bt2]
    dr2 = [ids[i] for i in dt2]
    cp, cr, _ = prediction(qt, scores, bt2)
    cb = ref.ndcg(br2, qrels[qid])
    ch = ref.ndcg(ref.rrf(br2, dr2, k=10), qrels[qid])
    rows.append(dict(query_id=qid, self_in_corpus=int(ix is not None),
        self_in_bm25_top5=int(qid in br), self_in_dense_top5=int(qid in dr),
        original_bm25=b, original_hybrid=h, original_router=r,
        original_run_dense=route, corrected_bm25=cb, corrected_hybrid=ch,
        corrected_router=ch if cr else cb, corrected_run_dense=cr,
        corrected_probability=cp, corrected_with_original_decisions=ch if route else cb,
        bm25_changed=int(br != br2), dense_changed=int(dr != dr2),
        route_changed=int(route != cr)))
    if n % 100 == 0:
        print(f'Validated {n}/1406', flush=True)

df = pd.DataFrame(rows)
k = int(df.corrected_run_dense.sum())
base = df.corrected_bm25.to_numpy()
gain = df.corrected_hybrid.to_numpy() - base
router = float(df.corrected_router.mean())
rng = np.random.default_rng(20261103)
exceeds = 0
for _ in range(50000):
    chosen = rng.choice(len(df), k, replace=False)
    score = base.mean() + gain[chosen].sum() / len(df)
    exceeds += int(score >= router - 1e-14)
summary = dict(analysis='post-confirmatory exploratory protocol sensitivity',
    historical_reproduced=True, queries=len(df),
    self_in_corpus=int(df.self_in_corpus.sum()),
    self_in_bm25_top5=int(df.self_in_bm25_top5.sum()),
    self_in_dense_top5=int(df.self_in_dense_top5.sum()),
    bm25_changed=int(df.bm25_changed.sum()),
    dense_changed=int(df.dense_changed.sum()),
    route_changed=int(df.route_changed.sum()),
    old_calls=int(df.original_run_dense.sum()), corrected_calls=k,
    old_bm25=float(df.original_bm25.mean()), corrected_bm25=float(base.mean()),
    old_hybrid=float(df.original_hybrid.mean()),
    corrected_hybrid=float(df.corrected_hybrid.mean()),
    old_router=float(df.original_router.mean()), corrected_router=router,
    corrected_with_old_decisions=float(df.corrected_with_original_decisions.mean()),
    random_expectation=float(base.mean() + k * gain.mean() / len(df)),
    p_exploratory=(exceeds + 1) / 50001,
    threshold=threshold)
out.mkdir(parents=True, exist_ok=True)
df.to_csv(out / 'arguana_selfmatch_per_query.csv', index=False)
(out / 'arguana_selfmatch_validation.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
pd.DataFrame([summary]).to_csv(out / 'arguana_selfmatch_summary.csv', index=False)
print(json.dumps(summary, indent=2))
print('Saved to', out)
