from __future__ import annotations
import argparse, json, platform, sys, time
from pathlib import Path
import numpy as np
import pandas as pd

import run_confirmatory_beir as ref

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs' / 'router' / 'arguana_selfmatch_audit'
TRAIN = ROOT / 'outputs' / 'router' / 'router_train_enriched.csv'
DATA = ROOT / 'datasets' / 'arguana'
EXPECTED = 0.4994615425106149


def find_audit_file():
    candidates = [OUT/'arguana_selfmatch_per_query.csv',
                  ROOT/'outputs'/'router'/'arguana_selfmatch_per_query.csv',
                  ROOT/'arguana_selfmatch_per_query.csv']
    return next((p for p in candidates if p.exists()), None)


def frozen_model():
    from sklearn.model_selection import StratifiedKFold
    df = pd.read_csv(TRAIN, dtype={'query_id': str})
    df = df[df['split'].eq('train')].reset_index(drop=True)
    assert len(df) == 647, 'Expected 647 SciFact train queries'
    X = df[ref.FEATURES].to_numpy(dtype=float)
    y = df.hybrid_helpful.to_numpy(dtype=int)
    oof = np.empty(len(df))
    for tr, te in StratifiedKFold(5, shuffle=True, random_state=42).split(X,y):
        m = ref.model_factory(); m.fit(X[tr],y[tr])
        oof[te] = m.predict_proba(X[te])[:,1]
    threshold = float(np.median(oof))
    if abs(threshold-EXPECTED)>1e-8:
        raise RuntimeError(f'FROZEN THRESHOLD DOES NOT MATCH: {threshold}')
    m=ref.model_factory(); m.fit(X,y)
    return df,m,threshold


def model_features(qtokens, top, scores, tsets, title_sets):
    qset=set(qtokens)
    vals=[len(qtokens),len(qset),float(scores[top[0]]),float(scores[top[1]]),
          float(scores[top[0]]-scores[top[1]]),float(np.mean(scores[top]))]
    vals += ref.extra_features(qset,top,scores,tsets,title_sets)
    if len(vals)!=11 or not np.all(np.isfinite(vals)):
        raise RuntimeError('Invalid 11-vector')
    return vals


def corrected_top(scores, exclude):
    if exclude is None:
        return np.argsort(-scores)[:5]
    tmp=scores.copy()
    tmp[exclude]=-np.inf
    return np.argsort(-tmp)[:5]


def timing_stats(x):
    return dict(mean_ms=float(x.mean()),median_ms=float(x.median()),
                p95_ms=float(x.quantile(.95)),p99_ms=float(x.quantile(.99)),n=int(x.size))


def do_benchmark(args,docs,queries,qrels,qids,ids,idmap,bm25,tsets,titles,model,threshold,audit):
    """Genuine online-like query processing; no doc embedding time; dataset-level CPU timings.

    Every policy independently executes BM25. Hybrid always encodes the query;
    corrected Router encodes it only when its frozen probability exceeds threshold.
    The self-document is omitted before top-5 selection in BOTH pathways.
    """
    from sentence_transformers import SentenceTransformer
    from datetime import datetime,timezone
    encoder=SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2',device='cpu')
    if encoder.max_seq_length!=256:
        raise RuntimeError('Unexpected dense context window')
    texts=[(docs[d].get('title','')+' '+docs[d].get('text','')).strip() for d in ids]
    print('Precomputing document vectors (excluded from query latency)...',flush=True)
    emb=encoder.encode(texts, batch_size=32,normalize_embeddings=True,
                       convert_to_numpy=True, show_progress_bar=True)
    encoder.encode(['warmup'],normalize_embeddings=True,convert_to_numpy=True)
    emb=np.asarray(emb,dtype=np.float32)
    if emb.shape != (len(ids),384):
        raise RuntimeError('Unexpected dense vector dimensions')
    rng=np.random.default_rng(20261106)
    records=[]
    seen=set()
    for repeat in range(args.repeats):
        order=np.asarray(qids)[rng.permutation(len(qids))]
        print(f'Benchmark repeat {repeat+1}/{args.repeats}...',flush=True)
        for n,qid in enumerate(order,1):
            qid=str(qid)
            q=queries[qid]
            qt=ref.tok(q)
            exclude=idmap.get(qid)
            # Alternate run order to mitigate systematic CPU drift.
            policies=['hybrid','router'] if rng.integers(0,2)==0 else ['router','hybrid']
            for policy in policies:
                t0=time.perf_counter()
                s=np.asarray(bm25.get_scores(qt), dtype=float)
                top=corrected_top(s,exclude)
                br=[ids[i] for i in top]
                if policy=='router':
                    features=model_features(qt,top,s,tsets,titles)
                    prob=float(model.predict_proba(np.asarray(features).reshape(1,-1))[0,1])
                    routed=int(prob>=threshold)
                else:
                    routed=1
                if routed:
                    qvec=encoder.encode([q],normalize_embeddings=True,convert_to_numpy=True)[0]
                    dtop=corrected_top(emb@qvec,exclude)
                    dr=[ids[i] for i in dtop]
                    rank=ref.rrf(br,dr,k=10)
                else:
                    rank=br
                time_ms=(time.perf_counter()-t0)*1000.0
                if policy=='router':
                    if routed != int(audit.loc[qid,'corrected_run_dense']):
                        raise RuntimeError(f'Corrected router decision changed for {qid}')
                    if repeat==0:
                        score=ref.ndcg(rank,qrels[qid])
                        expected_score=float(audit.loc[qid,'corrected_router'])
                        if abs(score-expected_score)>1e-8:
                            raise RuntimeError(f'Corrected Router nDCG mismatch in DIRECT benchmark for {qid}')
                    seen.add(qid)
                elif repeat==0:
                    score=ref.ndcg(rank,qrels[qid])
                    expected_score=float(audit.loc[qid,'corrected_hybrid'])
                    if abs(score-expected_score)>1e-8:
                        raise RuntimeError(f'Corrected Hybrid nDCG mismatch in DIRECT benchmark for {qid}')
                records.append(dict(query_id=qid,repeat=repeat+1,policy=policy,
                                    time_ms=time_ms,dense_called=routed))
            if n%100==0: print(f'  {n}/{len(qids)}',flush=True)
    result=pd.DataFrame(records)
    if len(seen)!=len(qids):
        raise RuntimeError('Not all corrected route decisions validated')
    summary=[]
    for policy,sub in result.groupby('policy'):
        summary.append({'policy':policy,**timing_stats(sub.time_ms),
                        'dense_rate':float(sub.dense_called.mean()),
                        'repeats':args.repeats,'method':'direct_CPU_warm_sequential'})
    summary=pd.DataFrame(summary)
    result.to_csv(OUT/'corrected_direct_latency_per_run.csv',index=False)
    summary.to_csv(OUT/'corrected_direct_latency_summary.csv',index=False)
    metadata={'analysis':'exploratory post-confirmatory corrected self-match latency',
              'processor':platform.processor(),'platform':platform.platform(),
              'python':sys.version,'dataset':'arguana','queries':len(qids),
              'repeats':args.repeats,'embedding_checkpoint':'sentence-transformers/all-MiniLM-L6-v2',
              'excluded':'document encoding/index preparation and process startup',
              'reported_utc':datetime.now(timezone.utc).isoformat(),
              'note':'Query BM25 and optional query dense encoder measured on same CPU; '
                     'small benchmark runs should not be generalized to all 1406 queries.'}
    (OUT/'corrected_direct_latency_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    print('DIRECT latency summary:\n',summary.to_string(index=False),flush=True)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--benchmark',action='store_true',help='Also perform DIRECT timing of corrected Hybrid and Router')
    ap.add_argument('--repeats',type=int,default=3,help='Per-query repetitions for direct timing, default 3')
    args=ap.parse_args()
    if args.repeats<1 or args.repeats>20: raise SystemExit('repeats must be 1..20')
    path=find_audit_file()
    if path is None:
        raise SystemExit('Missing arguana_selfmatch_per_query.csv: copy it to outputs/router/arguana_selfmatch_audit/')
    if not (DATA/'corpus.jsonl').exists() or not (DATA/'queries.jsonl').exists():
        raise SystemExit(f'Missing official dataset at {DATA}; keep the same data used in selfmatch audit.')
    expected=pd.read_csv(path,dtype={'query_id':str}).set_index('query_id')
    if expected.index.has_duplicates or len(expected)!=1406:
        raise RuntimeError('Expected 1406 unique query IDs in corrected audit file')
    src,model,threshold=frozen_model()
    from beir.datasets.data_loader import GenericDataLoader
    from rank_bm25 import BM25Okapi
    docs,queries,qrels=GenericDataLoader(data_folder=str(DATA)).load(split='test')
    qids=sorted(qrels)
    if set(qids)!=set(expected.index):
        raise RuntimeError('BEIR test set differs from corrected query audit')
    ids=list(docs); idmap={d:i for i,d in enumerate(ids)}
    texts=[(docs[d].get('title','')+' '+docs[d].get('text','')).strip() for d in ids]
    tokens=[ref.tok(s) for s in texts]
    tsets=[set(t) for t in tokens]
    titles=[set(ref.tok(docs[d].get('title',''))) for d in ids]
    bm25=BM25Okapi(tokens)
    print('Recomputing corrected BM25 rankings and all 11 features...',flush=True)
    rows=[]
    for n,qid in enumerate(qids,1):
        qt=ref.tok(queries[qid])
        scores=np.asarray(bm25.get_scores(qt),dtype=float)
        top=corrected_top(scores,idmap.get(qid))
        features=model_features(qt,top,scores,tsets,titles)
        prob=float(model.predict_proba(np.asarray(features).reshape(1,-1))[0,1])
        route=int(prob>=threshold)
        if abs(prob-float(expected.loc[qid,'corrected_probability']))>1e-8:
            raise RuntimeError(f'Probability mismatch for {qid}: {prob} vs historical corrected')
        if route!=int(expected.loc[qid,'corrected_run_dense']):
            raise RuntimeError(f'Decision mismatch for {qid}')
        b=ref.ndcg([ids[i] for i in top],qrels[qid])
        if abs(b-float(expected.loc[qid,'corrected_bm25']))>1e-8:
            raise RuntimeError(f'Corrected BM25 nDCG mismatch for {qid}')
        rows.append(dict(query_id=qid,**dict(zip(ref.FEATURES,features)),
                         corrected_probability=prob,corrected_dense_call=route,
                         corrected_hybrid_gain=float(expected.loc[qid,'corrected_hybrid']-b)))
        if n%200==0: print(f'  {n}/{len(qids)}',flush=True)
    target=pd.DataFrame(rows)
    if int(target.corrected_dense_call.sum())!=1185:
        raise RuntimeError('Unexpected corrected dense call count')
    results=[]
    for name in ref.FEATURES:
        s=src[name].to_numpy(dtype=float)
        t=target[name].to_numpy(dtype=float)
        std=np.std(s,ddof=0)
        results.append(dict(feature=name,source_mean=float(s.mean()),source_std=float(std),
             corrected_target_mean=float(t.mean()),corrected_target_median=float(np.median(t)),
             standardized_mean_shift=float((t.mean()-s.mean())/std),
             fraction_target_above_source_p95=float(np.mean(t>np.quantile(s,.95))),
             fraction_target_below_source_p05=float(np.mean(t<np.quantile(s,.05)))))
    shifts=pd.DataFrame(results)
    # Linear log-odds contributions under the trained scaler and LR.
    scaler=model.named_steps['standardscaler']
    lr=model.named_steps['logisticregression']
    z=scaler.transform(target[ref.FEATURES].to_numpy(float))
    contribs=z*lr.coef_[0][None,:]
    contributions=pd.DataFrame({'feature':ref.FEATURES,
            'mean_logit_contribution':contribs.mean(axis=0),
            'median_logit_contribution':np.median(contribs,axis=0),
            'mean_abs_logit_contribution':np.mean(np.abs(contribs),axis=0)})
    OUT.mkdir(parents=True,exist_ok=True)
    target.to_csv(OUT/'corrected_all_11_feature_query_diagnostics.csv',index=False)
    shifts.to_csv(OUT/'corrected_all_11_feature_shift.csv',index=False)
    contributions.to_csv(OUT/'corrected_logit_contributions.csv',index=False)
    md={'analysis':'post-confirmatory exploratory self-match correction',
        'rows':len(target),'corrected_calls':int(target.corrected_dense_call.sum()),
        'threshold':threshold,'max_abs_prob_error_vs_audit':float(np.max(np.abs(
                  target.corrected_probability.to_numpy()-expected.loc[target.query_id,'corrected_probability'].to_numpy()))),
        'source':'647 SciFact training queries','corpus':'official BEIR/ArguAna'}
    (OUT/'corrected_11_feature_validation.json').write_text(json.dumps(md,indent=2),encoding='utf-8')
    print('Validated all 11 corrected features, dense calls, and BM25 nDCG. Output:',OUT,flush=True)
    if args.benchmark:
        do_benchmark(args,docs,queries,qrels,qids,ids,idmap,bm25,tsets,titles,model,threshold,expected)

if __name__=='__main__': main()
